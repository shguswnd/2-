package Common;

import User.User;

// Ŭ���� ����

public class ReadingroomFactory extends returnmessage{
	public User getUser() {
		return new User();
	}
	public void createRoom(String type) {
		
	}
}
