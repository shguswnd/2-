
public class ReadingroomEx {
	
	public static void main(String[] args) {
		
		SystemEx system = new SystemEx();
		system.run();
		

	}

}
